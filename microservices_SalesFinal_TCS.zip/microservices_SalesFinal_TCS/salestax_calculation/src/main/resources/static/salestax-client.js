function updateStats(alias) {
    $.ajax({
        url: "http://localhost:8080/results?alias=" + alias,
        
    }).then(function(data) {
        $('#stats-body').empty();
        data.forEach(function(row) {
            $('#stats-body').append('<tr><td>' + row.multiplication.factorD + '</td>' +
                '<td>' + row.multiplication.factorA  + '</td>' + 
                '<td>'  + parseInt(row.multiplication.factorB) + '</td>' + 
                '<td>'  + parseInt(row.multiplication.factorB) * parseInt(row.multiplication.factorA)/100  +  '</td>' + 
                '<td>' + row.correct + '</td></tr>');
        });
    });
}
  function getSelectedOption(sel) {
        var opt;
        for ( var i = 0, len = sel.options.length; i < len; i++ ) {
            opt = sel.options[i];
            if ( opt.selected === true ) {
                break;
            }
        }
        return opt;
    }
    


$(document).ready(function() {
    $("#attempt-form").submit(function( event ) {

        // Don't submit the form normally
        event.preventDefault();
        var $form = $( this ),
            productname =$form.find( "input[name='product-name']" ).val(),
            productprice =$form.find( "input[name='product-price']" ).val(),
            
            producttaxes = $form.find( "input[name='product-taxes']" ).val(),
            productimporttaxes= $form.find( "input[name='product-importtax']" ).val(),            
            productcount =$form.find( "input[name='product-count']" ).val(),            
            attempt = $form.find( "input[name='result-attempt']" ).val(),
            userAlias = $form.find( "input[name='user-alias']" ).val();
            
             var imp = document.getElementById('imported');
             var opt = document.getElementById('nonTax');
             
             var opt1 = getSelectedOption(opt);
             var imp1 = getSelectedOption(imp);
            
 
            
           //producttax = opt1 + imp1);
           producttax =0;
           if (producttaxes === "Others")
               producttax = 10;
           if (productimporttaxes === "Imported")
               producttax = parseInt(producttax) + 5;
           
          //producttax = parseInt(producttaxes) + parseInt(productimporttaxes);
         // Compose the data in the format that the API is expecting
        var data = { user: { alias: userAlias}, multiplication: {factorA: productprice, factorB: producttax,factorC: productcount,factorD: productname}, resultAttempt: attempt};
        // var data = { product: { alias: productAlias},salestax: {pName: productname,pType: productType,pTax:producttax, pCount:productcount},`: attempt};
        

        // Send the data using post
        $.ajax({
            url: '/results',
            type: 'POST',
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            async: false,
            success: function(result){
                if(result.correct) {
                    $('.result-message').empty();
                } else {
                    $('.result-message').empty();
                }
            }
        });

        updateStats(userAlias);
       // updateProductTax(userAlias);
    });
});
