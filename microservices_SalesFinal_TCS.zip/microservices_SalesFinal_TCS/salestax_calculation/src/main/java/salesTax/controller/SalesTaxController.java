package salesTax.controller;

import salesTax.domain.SalesTax;
import salesTax.service.SalesTaxService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class implements a REST API for our SalesTax application.
 */
@RestController
@RequestMapping("/multiplications")
final class SalesTaxController {

    private final SalesTaxService multiplicationService;

    @Autowired
    public SalesTaxController(final SalesTaxService multiplicationService) {
        this.multiplicationService = multiplicationService;
    }

  
}
