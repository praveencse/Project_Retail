package salesTax.controller;

import salesTax.domain.SalesTaxResultAttempt;
import salesTax.service.SalesTaxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * This class provides a REST API to POST the attempts from users.
 */
@RestController
@RequestMapping("/results")
final class SalesTaxResultAttemptController {

    private final SalesTaxService multiplicationService;

    @Autowired
    SalesTaxResultAttemptController(final SalesTaxService multiplicationService) {
        this.multiplicationService = multiplicationService;
    }

    @PostMapping
    ResponseEntity<SalesTaxResultAttempt> postResult(@RequestBody SalesTaxResultAttempt multiplicationResultAttempt) {
        float isCorrect = multiplicationService.checkAttempt(multiplicationResultAttempt);
        SalesTaxResultAttempt attemptCopy = new SalesTaxResultAttempt(
                multiplicationResultAttempt.getUser(),
                multiplicationResultAttempt.getMultiplication(),
                multiplicationResultAttempt.getResultAttempt(),
                isCorrect,
                multiplicationResultAttempt.getTotalAmount()          
        );
        return ResponseEntity.ok(attemptCopy);
    }

    @GetMapping
    ResponseEntity<List<SalesTaxResultAttempt>> getStatistics(@RequestParam("alias") String alias) {
        return ResponseEntity.ok(
                multiplicationService.getStatsForUser(alias)
        );
    }

}
