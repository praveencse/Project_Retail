package salesTax.domain;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

/**
 * Identifies the attempt from a {@link User} to solve a
 * {@link SalesTax}.
 */
@RequiredArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Entity
public final class SalesTaxResultAttempt {

    @Id
    @GeneratedValue
    private Long id;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "USER_ID")
    private final User user;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "MULTIPLICATION_ID")
    private final SalesTax multiplication;
    private final float resultAttempt;

    private final float correct;
    private final float totalAmount;
 
    // Empty constructor for JSON/JPA
    SalesTaxResultAttempt() {
        user = null;
        multiplication = null;
        resultAttempt = -1;
        correct = 0;
        totalAmount = 0;
    }

}
