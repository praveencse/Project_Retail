package salesTax.repository;

import salesTax.domain.SalesTaxResultAttempt;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * This interface allow us to store and retrieve attempts
 */
public interface SalesTaxResultAttemptRepository
        extends CrudRepository<SalesTaxResultAttempt, Long> {

    /**
     * @return the latest 5 attempts for a given user, identified by their alias.
     */
    List<SalesTaxResultAttempt> findTop5ByUserAliasOrderByIdDesc(String userAlias);
}
