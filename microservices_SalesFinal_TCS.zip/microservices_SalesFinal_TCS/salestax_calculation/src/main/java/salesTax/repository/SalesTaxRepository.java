package salesTax.repository;

import salesTax.domain.SalesTax;
import org.springframework.data.repository.CrudRepository;

/**
 * This interface allows us to save and retrieve Multiplications
 */
public interface SalesTaxRepository extends CrudRepository<SalesTax, Long> {
}
