package salesTax.service;

import salesTax.domain.SalesTax;
import salesTax.domain.SalesTaxResultAttempt;
import salesTax.domain.User;
import salesTax.repository.SalesTaxResultAttemptRepository;
import salesTax.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
class SalesTaxServiceImpl implements SalesTaxService {

    private SalesTaxResultAttemptRepository attemptRepository;
    private UserRepository userRepository;
    public float totalAmount;

    @Autowired
    public SalesTaxServiceImpl(final SalesTaxResultAttemptRepository attemptRepository,
                                     final UserRepository userRepository) {
        this.attemptRepository = attemptRepository;
        this.userRepository = userRepository;
        this.totalAmount = 0;
    }

    @Transactional
    @Override
    public float checkAttempt(final SalesTaxResultAttempt attempt) {
        // Check if the user already exists for that alias
        Optional<User> user = userRepository.findByAlias(attempt.getUser().getAlias());

        // Avoids 'hack' attempts
      //  Assert.isTrue(!attempt.isCorrect(), "You can't send an attempt marked as correct!!");

        // Check if the attempt is correct
        float taxAmount = attempt.getMultiplication().getFactorA() * attempt.getMultiplication().getFactorB()/100;
        float productCost =  attempt.getMultiplication().getFactorA() + taxAmount;
        float tAmount = attempt.getMultiplication().getFactorC() * productCost;
                       
        totalAmount = totalAmount + tAmount;       

        SalesTaxResultAttempt checkedAttempt = new SalesTaxResultAttempt(
                user.orElse(attempt.getUser()),
                attempt.getMultiplication(),
                taxAmount,
                totalAmount,
                totalAmount
        );

        // Stores the attempt
        attemptRepository.save(checkedAttempt);

        return taxAmount;
    }

    @Override
    public List<SalesTaxResultAttempt> getStatsForUser(String userAlias) {
        return attemptRepository.findTop5ByUserAliasOrderByIdDesc(userAlias);
    }

}
