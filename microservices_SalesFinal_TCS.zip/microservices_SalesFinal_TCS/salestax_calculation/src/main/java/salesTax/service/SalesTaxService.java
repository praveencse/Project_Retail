package salesTax.service;

import salesTax.domain.SalesTax;
import salesTax.domain.SalesTaxResultAttempt;

import java.util.List;

public interface SalesTaxService {

      /**
     * @return true if the attempt matches the result of the
     *         multiplication, false otherwise.
     */
    float checkAttempt(final SalesTaxResultAttempt resultAttempt);

    /**
     * Gets the statistics for a given user.
     *
     * @param userAlias the user's alias
     * @return a list of {@link SalesTaxResultAttempt} objects, being the past attempts of the user.
     */
    List<SalesTaxResultAttempt> getStatsForUser(final String userAlias);

}
